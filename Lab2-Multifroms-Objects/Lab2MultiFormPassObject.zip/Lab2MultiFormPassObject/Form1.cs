namespace Lab2MultiFormPassObject
{
    public partial class frmYourName : Form
    {
        public frmYourName()
        {
            InitializeComponent();
        }
    }
}
