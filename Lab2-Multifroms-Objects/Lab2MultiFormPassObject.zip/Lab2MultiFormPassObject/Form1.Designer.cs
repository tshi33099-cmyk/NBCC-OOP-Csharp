﻿namespace Lab2MultiFormPassObject
{
    partial class frmYourName
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstItems = new ListBox();
            label1 = new Label();
            grpSelectedItem = new GroupBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            lblItemID = new Label();
            lblName = new Label();
            lblPrice = new Label();
            lblDate = new Label();
            lblDescription = new Label();
            btnLoad = new Button();
            btnClear = new Button();
            btnEdit = new Button();
            btnSave = new Button();
            grpSelectedItem.SuspendLayout();
            SuspendLayout();
            // 
            // lstItems
            // 
            lstItems.FormattingEnabled = true;
            lstItems.Location = new Point(12, 12);
            lstItems.Name = "lstItems";
            lstItems.Size = new Size(405, 324);
            lstItems.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 35);
            label1.Name = "label1";
            label1.Size = new Size(61, 20);
            label1.TabIndex = 1;
            label1.Text = "Item ID:";
            // 
            // grpSelectedItem
            // 
            grpSelectedItem.Controls.Add(lblDescription);
            grpSelectedItem.Controls.Add(lblDate);
            grpSelectedItem.Controls.Add(lblPrice);
            grpSelectedItem.Controls.Add(lblName);
            grpSelectedItem.Controls.Add(lblItemID);
            grpSelectedItem.Controls.Add(label5);
            grpSelectedItem.Controls.Add(label4);
            grpSelectedItem.Controls.Add(label3);
            grpSelectedItem.Controls.Add(label2);
            grpSelectedItem.Controls.Add(label1);
            grpSelectedItem.Location = new Point(440, 12);
            grpSelectedItem.Name = "grpSelectedItem";
            grpSelectedItem.Size = new Size(332, 250);
            grpSelectedItem.TabIndex = 2;
            grpSelectedItem.TabStop = false;
            grpSelectedItem.Text = "Selected Item";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 67);
            label2.Name = "label2";
            label2.Size = new Size(52, 20);
            label2.TabIndex = 2;
            label2.Text = "Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 99);
            label3.Name = "label3";
            label3.Size = new Size(44, 20);
            label3.TabIndex = 3;
            label3.Text = "Price:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 163);
            label4.Name = "label4";
            label4.Size = new Size(88, 20);
            label4.TabIndex = 4;
            label4.Text = "Description:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 131);
            label5.Name = "label5";
            label5.Size = new Size(124, 20);
            label5.TabIndex = 5;
            label5.Text = "Best Before Date:";
            // 
            // lblItemID
            // 
            lblItemID.BackColor = SystemColors.ControlLightLight;
            lblItemID.BorderStyle = BorderStyle.FixedSingle;
            lblItemID.Location = new Point(150, 34);
            lblItemID.Name = "lblItemID";
            lblItemID.Size = new Size(162, 25);
            lblItemID.TabIndex = 6;
            // 
            // lblName
            // 
            lblName.BackColor = SystemColors.ControlLightLight;
            lblName.BorderStyle = BorderStyle.FixedSingle;
            lblName.Location = new Point(150, 66);
            lblName.Name = "lblName";
            lblName.Size = new Size(162, 25);
            lblName.TabIndex = 7;
            // 
            // lblPrice
            // 
            lblPrice.BackColor = SystemColors.ControlLightLight;
            lblPrice.BorderStyle = BorderStyle.FixedSingle;
            lblPrice.Location = new Point(150, 98);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(162, 25);
            lblPrice.TabIndex = 8;
            // 
            // lblDate
            // 
            lblDate.BackColor = SystemColors.ControlLightLight;
            lblDate.BorderStyle = BorderStyle.FixedSingle;
            lblDate.Location = new Point(150, 130);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(162, 25);
            lblDate.TabIndex = 9;
            // 
            // lblDescription
            // 
            lblDescription.BackColor = SystemColors.ControlLightLight;
            lblDescription.BorderStyle = BorderStyle.FixedSingle;
            lblDescription.Location = new Point(6, 183);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(306, 54);
            lblDescription.TabIndex = 10;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(446, 268);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(146, 32);
            btnLoad.TabIndex = 3;
            btnLoad.Text = "Load";
            btnLoad.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(606, 268);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(146, 32);
            btnClear.TabIndex = 4;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            // 
            // btnEdit
            // 
            btnEdit.Location = new Point(446, 306);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(146, 32);
            btnEdit.TabIndex = 5;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(606, 306);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(146, 32);
            btnSave.TabIndex = 6;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            // 
            // frmYourName
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(785, 344);
            Controls.Add(btnSave);
            Controls.Add(btnEdit);
            Controls.Add(btnClear);
            Controls.Add(btnLoad);
            Controls.Add(grpSelectedItem);
            Controls.Add(lstItems);
            Name = "frmYourName";
            Text = "Your Name";
            grpSelectedItem.ResumeLayout(false);
            grpSelectedItem.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private ListBox lstItems;
        private Label label1;
        private GroupBox grpSelectedItem;
        private Label lblItemID;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label lblDescription;
        private Label lblDate;
        private Label lblPrice;
        private Label lblName;
        private Button btnLoad;
        private Button btnClear;
        private Button btnEdit;
        private Button btnSave;
    }
}
